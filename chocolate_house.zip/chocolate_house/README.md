# Chocolate House Management Application

This application helps manage seasonal flavor offerings, ingredient inventory, and customer flavor suggestions with allergy concerns for a fictional chocolate house.

## Setup

1. Clone the repository:
   ```bash
   git clone <repository-link>
   cd chocolate_house
