from db import get_db_connection

# Existing insert functions...

# Fetch all seasonal flavors
def get_all_flavors():
    conn = get_db_connection()
    flavors = conn.execute("SELECT * FROM flavors").fetchall()
    conn.close()
    return flavors

# Fetch all ingredients
def get_all_ingredients():
    conn = get_db_connection()
    ingredients = conn.execute("SELECT * FROM ingredients").fetchall()
    conn.close()
    return ingredients

# Fetch all customer suggestions
def get_all_suggestions():
    conn = get_db_connection()
    suggestions = conn.execute("SELECT * FROM suggestions").fetchall()
    conn.close()
    return suggestions
