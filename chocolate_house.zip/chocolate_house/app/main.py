from flask import Flask, render_template, request, redirect, url_for
from models import add_flavor, add_ingredient, add_suggestion, get_all_flavors, get_all_ingredients, get_all_suggestions
from db import setup_database

app = Flask(__name__)

# Set up the database initially
setup_database()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/flavors', methods=['GET', 'POST'])
def flavors():
    if request.method == 'POST':
        name = request.form['name']
        season = request.form['season']
        add_flavor(name, season)
        return redirect(url_for('flavors'))
    flavors = get_all_flavors()
    return render_template('flavors.html', flavors=flavors)

@app.route('/ingredients', methods=['GET', 'POST'])
def ingredients():
    if request.method == 'POST':
        name = request.form['name']
        stock = int(request.form['stock'])
        add_ingredient(name, stock)
        return redirect(url_for('ingredients'))
    ingredients = get_all_ingredients()
    return render_template('ingredients.html', ingredients=ingredients)

@app.route('/suggestions', methods=['GET', 'POST'])
def suggestions():
    if request.method == 'POST':
        flavor_name = request.form['flavor_name']
        allergies = request.form['allergies']
        add_suggestion(flavor_name, allergies)
        return redirect(url_for('suggestions'))
    suggestions = get_all_suggestions()
    return render_template('suggestions.html', suggestions=suggestions)

if __name__ == "__main__":
    app.run(debug=True)
